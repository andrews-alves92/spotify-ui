import usePlayerContext from "@/app/context-providers/PlayerContextProvider/usePlayerContext";
import { PiRepeatBold, PiShuffleBold } from "react-icons/pi";
import { RiSkipBackFill, RiSkipForwardFill } from "react-icons/ri";
import PlayButton from "../../PlayButton";

export default function PlayerControls() {
  return (
    <div className="d-flex flex-row align-items-center gap-3 pe-2">
      <PlayButton />
      <RiSkipBackFill size={22} role="button" />
      <RiSkipForwardFill size={22} role="button" />
      <PiShuffleBold size={20} role="button" />
    </div>
  );
}
