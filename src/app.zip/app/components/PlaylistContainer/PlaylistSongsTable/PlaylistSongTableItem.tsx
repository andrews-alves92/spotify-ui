import { Song } from "@/app/entities";
import { formatSecondsToMinutes } from "@/app/utils/formatters";
import Image from "next/image";
import { LuHeart } from "react-icons/lu";
import Style from "./playlist-songs-table.module.css";

interface PlaylistSongTableItemProps {
  song: Song;
  index: number;
  isPlaying: boolean;
  isFavorite: boolean;
  handleSelected: (song: Song) => void;
}

export default function PlaylistSongTableItem({
  song,
  isPlaying,
  index,
  handleSelected,
}: PlaylistSongTableItemProps) {
  const onDoubleClick = () => {
    handleSelected(song);
  };
  return (
    <tr
      className={`small ${Style.itemContainer}`}
      onDoubleClick={onDoubleClick}
    >
      <th className="" scope="row ">
        {index + 1}
      </th>
      <td className="">
        <div className="flex-1 justify-content-start gap-3 align-items-center">
          <Image
            src={`/albuns/${song.album_cover}`}
            className="rounded"
            height={45}
            width={45}
            alt="Album cover image"
          />
          <div className="d-flex flex-column">
            <span className={isPlaying ? "text-primary" : "text-light"}>
              {song.name}
            </span>
            <span>{song.artist}</span>
          </div>
        </div>
      </td>
      <td className="">{song.album}</td>
      <td className="">{formatSecondsToMinutes(song.duration)}</td>
      <td className="">
        <LuHeart size={18} />
      </td>
    </tr>
  );
}
