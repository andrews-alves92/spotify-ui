export type Song = {
    id: string;
    name: string;
    artist: string;
    album: string;
    duration: number;
    album_cover: string;
}